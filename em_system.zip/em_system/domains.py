"""
SQND Ethical Module System - Domain Modules
============================================

Domain-specific modules extracted from Dear Abby corpus.
Each module has empirically-derived base rates and semantic gates.
"""

import re
from typing import List, Tuple
from .core import (
    EthicalModule, Case, EthicalJudgment,
    Verdict, HohfeldianState
)


class DomainEM(EthicalModule):
    """Base class for domain-specific modules"""
    
    def __init__(self, name: str, description: str, 
                 domain_tag: str,
                 base_o_rate: float,
                 base_l_rate: float,
                 corpus_count: int):
        super().__init__(name, description, priority=100)
        self.domain_tag = domain_tag
        self.base_o_rate = base_o_rate
        self.base_l_rate = base_l_rate
        self.empirical_basis = {
            "corpus_count": corpus_count,
            "base_o_rate": base_o_rate,
            "base_l_rate": base_l_rate,
            "source": "Dear Abby 1985-2017"
        }
        
        # Semantic gates: list of (pattern, effect, new_state)
        self.o_to_l_gates: List[Tuple[str, str, float]] = []
        self.l_to_o_gates: List[Tuple[str, str, float]] = []
    
    def applies_to(self, case: Case) -> bool:
        return self.domain_tag in case.domain_hints
    
    def _check_gates(self, case: Case, gates: List[Tuple[str, str, float]]) -> Tuple[bool, str, float]:
        """Check if any gate pattern matches. Returns (matched, reason, confidence)"""
        text = (case.raw_text or case.description).lower()
        for pattern, reason, conf in gates:
            if re.search(pattern, text):
                return True, reason, conf
        return False, "", 0.0


class PromiseEM(DomainEM):
    """
    Promise domain module.
    
    HIGHEST O-RATE of all domains (32.2%).
    Promises are the primary obligation generator.
    
    Key insight: "Only if convenient" produces DISCRETE flip,
    supporting D4 gate model over SU(2) continuous.
    """
    
    def __init__(self):
        super().__init__(
            name="Promise",
            description="Evaluates promise-based obligations",
            domain_tag="PROMISE",
            base_o_rate=0.322,
            base_l_rate=0.096,
            corpus_count=1449
        )
        
        # O→L gates (release triggers)
        self.o_to_l_gates = [
            (r'\bonly if (convenient|it\'s ok|you want)\b', 
             "DISCRETE GATE: 'only if convenient' releases obligation", 0.95),
            (r'\bno (pressure|obligation|strings)\b',
             "DISCRETE GATE: 'no pressure' releases obligation", 0.90),
            (r'\bfeel free\b',
             "DISCRETE GATE: 'feel free' releases obligation", 0.85),
            (r'\bdon\'t (have to|need to|worry)\b',
             "'Don't have to' releases obligation", 0.85),
            (r'\bif you (want|can|have time)\b',
             "Conditional phrasing weakens obligation", 0.70),
            (r'\b(released|relieved|excused) (from|of)\b',
             "Explicit release language", 0.95),
        ]
        
        # L→O gates (binding triggers)  
        self.l_to_o_gates = [
            (r'\bi promise\b',
             "'I promise' creates obligation", 0.95),
            (r'\bi (agree|agreed)\b',
             "'I agree' creates obligation", 0.90),
            (r'\b(committed|commitment)\b',
             "Commitment language creates obligation", 0.85),
            (r'\bgave (my|his|her|their) word\b',
             "'Gave word' creates strong obligation", 0.95),
            (r'\bsigned\b.*\b(contract|agreement)\b',
             "Signed contract creates strongest obligation", 0.99),
            (r'\b(vowed|swore|sworn)\b',
             "Vow/oath creates obligation", 0.90),
        ]
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if not self.applies_to(case):
            return self._abstain("Not a promise case")
        
        # Check for explicit promise fact
        has_promise = case.fact_value("promise_made", False)
        
        # Check release gates first (they override binding)
        released, reason, conf = self._check_gates(case, self.o_to_l_gates)
        if released:
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=conf,
                reasons=[reason],
                gate_type="O_to_L"
            )
        
        # Check binding gates
        bound, reason, conf = self._check_gates(case, self.l_to_o_gates)
        if bound or has_promise:
            return self._judgment(
                Verdict.OBLIGATE,
                HohfeldianState.O,
                confidence=conf if bound else 0.85,
                reasons=[reason if bound else "Promise fact present"],
                gate_type="L_to_O" if bound else "fact"
            )
        
        # Default: no clear determination
        return self._judgment(
            Verdict.CONDITIONAL,
            confidence=0.5,
            reasons=["No clear promise or release pattern detected"],
            base_o_rate=self.base_o_rate
        )


class FamilyEM(DomainEM):
    """
    Family domain module.
    
    71.4% of corpus but only 18.5% O-rate.
    Key insight: Family creates PRESSURE but not automatic OBLIGATION.
    Blood relation alone is insufficient.
    """
    
    def __init__(self):
        super().__init__(
            name="Family",
            description="Evaluates family-based obligations",
            domain_tag="FAMILY",
            base_o_rate=0.185,
            base_l_rate=0.090,
            corpus_count=14304
        )
        
        # Relationship-specific base rates
        self.relationship_rates = {
            "parent_to_minor": (0.90, "O"),  # Strong obligation
            "child_to_elderly": (0.60, "O"),  # Moderate, contested
            "parent_to_adult": (0.20, "L"),  # Respect autonomy
            "sibling": (0.15, "L"),  # No inherent duty
            "in_law": (0.18, "L"),  # No blood duty
            "extended": (0.12, "L"),  # Cultural pressure ≠ O
        }
        
        self.o_to_l_gates = [
            (r'\b(estranged|estrangement)\b',
             "Estrangement nullifies family obligation", 0.85),
            (r'\b(toxic|narcissis|manipulat)\b',
             "Toxic relationship weakens obligation", 0.75),
            (r'\bno contact\b',
             "No-contact status nullifies obligation", 0.85),
            (r'\bforgive\b',
             "Forgiveness releases past obligation", 0.70),
        ]
        
        self.l_to_o_gates = [
            (r'\bpromised\b',
             "Promise to family creates obligation", 0.85),
            (r'\b(dependent|depends on|relies on)\b',
             "Dependency creates obligation", 0.80),
            (r'\b(sick|ill|dying|elderly)\b.*\b(care|help)\b',
             "Vulnerability creates obligation", 0.70),
        ]
    
    def _detect_relationship(self, case: Case) -> str:
        """Detect the family relationship type"""
        text = (case.raw_text or case.description).lower()
        
        if re.search(r'\b(my child|my son|my daughter)\b.*\b(minor|young|kid)\b', text):
            return "parent_to_minor"
        if re.search(r'\b(elderly|aging|old)\b.*\b(parent|mother|father)\b', text):
            return "child_to_elderly"
        if re.search(r'\b(adult)\b.*\b(child|son|daughter)\b', text):
            return "parent_to_adult"
        if re.search(r'\b(sister|brother|sibling)\b', text):
            return "sibling"
        if re.search(r'\b(in-law|mother-in-law|father-in-law)\b', text):
            return "in_law"
        if re.search(r'\b(aunt|uncle|cousin|niece|nephew)\b', text):
            return "extended"
        
        return "unknown"
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if not self.applies_to(case):
            return self._abstain("Not a family case")
        
        # Check release gates
        released, reason, conf = self._check_gates(case, self.o_to_l_gates)
        if released:
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=conf,
                reasons=[reason],
                gate_type="O_to_L"
            )
        
        # Check binding gates
        bound, reason, conf = self._check_gates(case, self.l_to_o_gates)
        if bound:
            return self._judgment(
                Verdict.OBLIGATE,
                HohfeldianState.O,
                confidence=conf,
                reasons=[reason],
                gate_type="L_to_O"
            )
        
        # Use relationship-specific rates
        rel_type = self._detect_relationship(case)
        if rel_type in self.relationship_rates:
            rate, default_state = self.relationship_rates[rel_type]
            state = HohfeldianState.O if default_state == "O" else HohfeldianState.L
            verdict = Verdict.OBLIGATE if default_state == "O" else Verdict.RELEASE
            return self._judgment(
                verdict,
                state,
                confidence=rate,
                reasons=[f"Family relationship type: {rel_type}"],
                relationship=rel_type
            )
        
        # Default family case
        return self._judgment(
            Verdict.CONDITIONAL,
            confidence=self.base_o_rate,
            reasons=["Family relation without clear obligation triggers"],
            base_o_rate=self.base_o_rate
        )


class FriendshipEM(DomainEM):
    """
    Friendship domain module.
    
    HIGHEST L-RATE (11.4%).
    Key insight: Friendship defaults to LIBERTY.
    "Can I refuse my friend?" is the paradigm case.
    """
    
    def __init__(self):
        super().__init__(
            name="Friendship",
            description="Evaluates friendship-based obligations",
            domain_tag="FRIENDSHIP",
            base_o_rate=0.213,
            base_l_rate=0.114,
            corpus_count=4990
        )
        
        self.o_to_l_gates = [
            (r'\b(never reciprocate|one-sided)\b',
             "One-sided friendship weakens obligation", 0.70),
            (r'\b(friendship (ended|over)|no longer friends)\b',
             "Ended friendship nullifies obligation", 0.90),
            (r'\b(toxic|using me|takes advantage)\b',
             "Toxic friendship weakens obligation", 0.80),
        ]
        
        self.l_to_o_gates = [
            (r'\b(said yes|agreed|accepted)\b',
             "Explicit acceptance creates obligation", 0.85),
            (r'\bbest friend\b',
             "'Best friend' framing slightly strengthens", 0.60),
            (r'\b(always|pattern|every time)\b.*\b(help|there)\b',
             "Established pattern creates weak obligation", 0.55),
        ]
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if not self.applies_to(case):
            return self._abstain("Not a friendship case")
        
        # Check release gates
        released, reason, conf = self._check_gates(case, self.o_to_l_gates)
        if released:
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=conf,
                reasons=[reason]
            )
        
        # Check binding gates
        bound, reason, conf = self._check_gates(case, self.l_to_o_gates)
        if bound:
            return self._judgment(
                Verdict.OBLIGATE,
                HohfeldianState.O,
                confidence=conf,
                reasons=[reason]
            )
        
        # Default: Friendship is LIBERTY
        return self._judgment(
            Verdict.RELEASE,
            HohfeldianState.L,
            confidence=self.base_l_rate / (self.base_l_rate + self.base_o_rate),
            reasons=["Friendship defaults to liberty without explicit acceptance"]
        )


class MoneyEM(DomainEM):
    """
    Money/debt domain module.
    
    Key insight: Money obligations are TIME-INVARIANT.
    "I forgot" doesn't release debt.
    """
    
    def __init__(self):
        super().__init__(
            name="Money",
            description="Evaluates money/debt obligations",
            domain_tag="MONEY",
            base_o_rate=0.174,
            base_l_rate=0.083,
            corpus_count=7330
        )
        
        self.o_to_l_gates = [
            (r'\b(forgive|forgave)\b.*\b(debt|loan|money)\b',
             "Debt forgiveness nullifies obligation", 0.95),
            (r'\bgift\b',
             "Gifts create no repayment obligation", 0.90),
            (r'\bbankruptcy\b',
             "Legal bankruptcy nullifies obligation", 0.95),
        ]
        
        self.l_to_o_gates = [
            (r'\b(loan|lend|lent|borrow|borrowed)\b',
             "Loan creates repayment obligation", 0.90),
            (r'\bpay (you|me|them) back\b',
             "'Pay back' creates obligation", 0.90),
            (r'\bowe[sd]?\b',
             "'Owe' indicates obligation", 0.85),
        ]
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if not self.applies_to(case):
            return self._abstain("Not a money case")
        
        # Check release gates
        released, reason, conf = self._check_gates(case, self.o_to_l_gates)
        if released:
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=conf,
                reasons=[reason]
            )
        
        # Check binding gates
        bound, reason, conf = self._check_gates(case, self.l_to_o_gates)
        if bound:
            return self._judgment(
                Verdict.OBLIGATE,
                HohfeldianState.O,
                confidence=conf,
                reasons=[reason, "Note: Money obligations are time-invariant"]
            )
        
        return self._judgment(
            Verdict.CONDITIONAL,
            confidence=0.5,
            reasons=["Money context without clear loan/gift determination"]
        )


class RomanticEM(DomainEM):
    """
    Romantic relationship module.
    
    Key insight: Romantic relationships create IMPLICIT O
    via commitment norms. Breakup nullifies.
    """
    
    def __init__(self):
        super().__init__(
            name="Romantic",
            description="Evaluates romantic relationship obligations",
            domain_tag="ROMANTIC",
            base_o_rate=0.259,
            base_l_rate=0.122,
            corpus_count=5671
        )
        
        self.o_to_l_gates = [
            (r'\b(broke up|break up|broken up|breakup)\b',
             "Breakup nullifies romantic obligations", 0.90),
            (r'\b(divorce|divorced)\b',
             "Divorce nullifies spousal obligations", 0.95),
            (r'\b(ex-|ex |former)\b.*(boyfriend|girlfriend|husband|wife|spouse)\b',
             "Ex-partner status: no residual obligation", 0.90),
            (r'\b(cheat|cheated|cheating|affair)\b',
             "Infidelity weakens cheater's claim", 0.80),
        ]
        
        self.l_to_o_gates = [
            (r'\b(married|marriage|spouse|husband|wife)\b',
             "Marriage creates multiple obligations", 0.85),
            (r'\b(exclusive|committed|serious)\b.*\b(relationship|dating)\b',
             "Committed relationship creates fidelity obligation", 0.75),
            (r'\b(engaged|engagement|fiance)\b',
             "Engagement creates obligations", 0.80),
        ]
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if not self.applies_to(case):
            return self._abstain("Not a romantic relationship case")
        
        # Check release gates
        released, reason, conf = self._check_gates(case, self.o_to_l_gates)
        if released:
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=conf,
                reasons=[reason]
            )
        
        # Check binding gates
        bound, reason, conf = self._check_gates(case, self.l_to_o_gates)
        if bound:
            return self._judgment(
                Verdict.OBLIGATE,
                HohfeldianState.O,
                confidence=conf,
                reasons=[reason]
            )
        
        return self._judgment(
            Verdict.CONDITIONAL,
            confidence=0.5,
            reasons=["Romantic context without clear commitment status"]
        )


class WeddingEM(DomainEM):
    """
    Wedding attendance module.
    
    Key insight: Wedding attendance defaults to WEAK O
    for close relations, but estrangement nullifies.
    """
    
    def __init__(self):
        super().__init__(
            name="Wedding",
            description="Evaluates wedding attendance obligations",
            domain_tag="WEDDING",
            base_o_rate=0.215,
            base_l_rate=0.097,
            corpus_count=5980
        )
        
        self.o_to_l_gates = [
            (r'\b(estranged|no contact)\b',
             "Estrangement nullifies attendance obligation", 0.85),
            (r'\b(ex-|ex |former)\b.*(spouse|husband|wife|boyfriend|girlfriend)\b',
             "Ex's wedding: no obligation", 0.90),
            (r'\b(can\'t afford|too expensive)\b',
             "Financial impossibility weakens obligation", 0.60),
        ]
        
        self.l_to_o_gates = [
            (r'\b(bridesmaid|groomsman|best man|maid of honor)\b',
             "Accepted wedding party role creates obligation", 0.90),
            (r'\bRSVP.*(yes|accepted)\b',
             "RSVP yes creates weak obligation", 0.70),
            (r'\b(sibling|parent|child)\'?s?\b.*\bwedding\b',
             "Close family wedding creates weak obligation", 0.65),
        ]
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if not self.applies_to(case):
            return self._abstain("Not a wedding case")
        
        # Check release gates
        released, reason, conf = self._check_gates(case, self.o_to_l_gates)
        if released:
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=conf,
                reasons=[reason]
            )
        
        # Check binding gates
        bound, reason, conf = self._check_gates(case, self.l_to_o_gates)
        if bound:
            return self._judgment(
                Verdict.OBLIGATE,
                HohfeldianState.O,
                confidence=conf,
                reasons=[reason]
            )
        
        # Friend's wedding: default liberty
        return self._judgment(
            Verdict.RELEASE,
            HohfeldianState.L,
            confidence=0.65,
            reasons=["Wedding invitation is not a summons"]
        )


class WorkplaceEM(DomainEM):
    """
    Workplace obligations module.
    """
    
    def __init__(self):
        super().__init__(
            name="Workplace",
            description="Evaluates workplace obligations",
            domain_tag="WORKPLACE",
            base_o_rate=0.199,
            base_l_rate=0.092,
            corpus_count=4299
        )
        
        self.o_to_l_gates = [
            (r'\bnot (my|in my) job\b',
             "'Not my job' indicates liberty if true", 0.70),
            (r'\b(quit|resigned|left the job)\b',
             "Employment ended: obligations end", 0.90),
        ]
        
        self.l_to_o_gates = [
            (r'\b(job description|contract|hired to)\b',
             "Contractual duty creates obligation", 0.90),
            (r'\bmanager\b.*(asked|told|requested)\b',
             "Manager request creates moderate obligation", 0.70),
            (r'\bpromised\b.*(boss|manager|coworker)\b',
             "Workplace promise creates obligation", 0.80),
        ]
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if not self.applies_to(case):
            return self._abstain("Not a workplace case")
        
        # Check release gates
        released, reason, conf = self._check_gates(case, self.o_to_l_gates)
        if released:
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=conf,
                reasons=[reason]
            )
        
        # Check binding gates
        bound, reason, conf = self._check_gates(case, self.l_to_o_gates)
        if bound:
            return self._judgment(
                Verdict.OBLIGATE,
                HohfeldianState.O,
                confidence=conf,
                reasons=[reason]
            )
        
        # Peer request: default liberty
        return self._judgment(
            Verdict.RELEASE,
            HohfeldianState.L,
            confidence=0.60,
            reasons=["Peer request without acceptance: liberty"]
        )
