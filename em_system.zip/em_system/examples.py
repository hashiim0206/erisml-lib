"""
SQND EM System - Example Usage
==============================

This file demonstrates how to use the EM-DAG system
extracted from the Dear Abby corpus.
"""

from em_system import (
    Case, HohfeldianState, create_default_dag,
    DAGConfig, EMDAGAggregator
)


def example_promise_with_release():
    """
    Example: Promise with 'only if convenient' release language.
    
    This demonstrates the discrete semantic gate - the phrase
    "only if convenient" flips O to L (supports D₄ model).
    """
    print("=" * 60)
    print("EXAMPLE 1: Promise with release language")
    print("=" * 60)
    
    case = Case(
        case_id="promise_001",
        description="""
        Morgan promised to help Alex move apartments on Saturday.
        They agreed on this three weeks ago. Yesterday, Morgan texted
        saying "I'll help if it's convenient, no pressure at all!"
        """,
        parties={"Morgan": "promisor", "Alex": "promisee"},
        party_of_interest="Morgan"
    )
    
    dag = create_default_dag()
    result = dag.evaluate(case)
    
    print(f"\nCase: {case.description.strip()}")
    print(f"\nDomains detected: {case.domain_hints}")
    print(f"\nMorgan's status: {result.final_state.value if result.final_state else 'Unknown'}")
    print(f"Verdict: {result.final_verdict.value}")
    print(f"Confidence: {result.confidence:.2f}")
    
    if result.correlative_party:
        print(f"\nCorrelative: {result.correlative_party} has {result.correlative_state.value}")
    
    print("\nContributing judgments:")
    for j in result.contributing_judgments:
        print(f"  - {j.em_name}: {j.verdict.value} ({j.confidence:.2f})")
        for reason in j.reasons:
            print(f"      {reason}")
    
    return result


def example_family_with_estrangement():
    """
    Example: Family obligation nullified by estrangement.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 2: Family obligation with estrangement")
    print("=" * 60)
    
    case = Case(
        case_id="family_001",
        description="""
        My estranged brother is getting married. We haven't spoken
        in three years after a terrible falling out. My mother insists
        I "have to" attend because "family is family."
        """,
        parties={"Writer": "sibling", "Brother": "sibling"},
        party_of_interest="Writer"
    )
    
    dag = create_default_dag()
    result = dag.evaluate(case)
    
    print(f"\nCase: {case.description.strip()}")
    print(f"\nDomains detected: {case.domain_hints}")
    print(f"\nWriter's status: {result.final_state.value if result.final_state else 'Unknown'}")
    print(f"Verdict: {result.final_verdict.value}")
    print(f"Confidence: {result.confidence:.2f}")
    
    if result.nullifier_triggered:
        print(f"\nNullifier triggered: {result.nullifier_triggered}")
    
    print("\nContributing judgments:")
    for j in result.contributing_judgments:
        print(f"  - {j.em_name}: {j.verdict.value} ({j.confidence:.2f})")
        for reason in j.reasons:
            print(f"      {reason}")
    
    return result


def example_abuse_nullifier():
    """
    Example: Abuse nullifies all obligations.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 3: Abuse nullifies obligation")
    print("=" * 60)
    
    case = Case(
        case_id="abuse_001",
        description="""
        My father was abusive throughout my childhood. Now he's elderly
        and expects me to take care of him. My siblings say I "owe" him
        because he's family.
        """,
        parties={"Writer": "child", "Father": "parent"},
        party_of_interest="Writer"
    )
    
    dag = create_default_dag()
    result = dag.evaluate(case)
    
    print(f"\nCase: {case.description.strip()}")
    print(f"\nDomains detected: {case.domain_hints}")
    print(f"\nWriter's status: {result.final_state.value if result.final_state else 'Unknown'}")
    print(f"Verdict: {result.final_verdict.value}")
    print(f"Confidence: {result.confidence:.2f}")
    
    if result.nullifier_triggered:
        print(f"\n*** NULLIFIER TRIGGERED: {result.nullifier_triggered} ***")
    
    return result


def example_money_debt():
    """
    Example: Money obligations are time-invariant.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 4: Debt obligation (time-invariant)")
    print("=" * 60)
    
    case = Case(
        case_id="money_001",
        description="""
        I borrowed $500 from my friend two years ago. I said I would
        pay them back. Life got busy and I forgot about it. They never
        reminded me. Do I still owe them?
        """,
        parties={"Writer": "borrower", "Friend": "lender"},
        party_of_interest="Writer"
    )
    
    dag = create_default_dag()
    result = dag.evaluate(case)
    
    print(f"\nCase: {case.description.strip()}")
    print(f"\nDomains detected: {case.domain_hints}")
    print(f"\nWriter's status: {result.final_state.value if result.final_state else 'Unknown'}")
    print(f"Verdict: {result.final_verdict.value}")
    print(f"Confidence: {result.confidence:.2f}")
    
    if result.correlative_party:
        print(f"\nCorrelative: {result.correlative_party} has {result.correlative_state.value}")
    
    print("\nNote: Money obligations persist regardless of time elapsed.")
    
    return result


def example_friendship_default_liberty():
    """
    Example: Friendship defaults to liberty.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 5: Friendship defaults to liberty")
    print("=" * 60)
    
    case = Case(
        case_id="friend_001",
        description="""
        My friend asked if I could help them move next weekend.
        I don't really want to. Can I say no?
        """,
        parties={"Writer": "friend", "Friend": "friend"},
        party_of_interest="Writer"
    )
    
    dag = create_default_dag()
    result = dag.evaluate(case)
    
    print(f"\nCase: {case.description.strip()}")
    print(f"\nDomains detected: {case.domain_hints}")
    print(f"\nWriter's status: {result.final_state.value if result.final_state else 'Unknown'}")
    print(f"Verdict: {result.final_verdict.value}")
    print(f"Confidence: {result.confidence:.2f}")
    
    print("\nNote: Friend requests without explicit acceptance = Liberty")
    
    return result


def example_custom_config():
    """
    Example: Using custom DAG configuration.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 6: Custom configuration")
    print("=" * 60)
    
    # Disable estrangement nullifier
    config = DAGConfig(
        name="Strict_Family_DAG",
        disabled_modules=["EstrangementNullifier"],
        min_confidence_threshold=0.7
    )
    
    case = Case(
        case_id="custom_001",
        description="""
        My estranged sister's wedding is next month.
        """,
        parties={"Writer": "sibling", "Sister": "sibling"},
        party_of_interest="Writer"
    )
    
    # Compare default vs custom
    default_dag = create_default_dag()
    custom_dag = EMDAGAggregator(config)
    
    default_result = default_dag.evaluate(case)
    custom_result = custom_dag.evaluate(case)
    
    print(f"\nCase: {case.description.strip()}")
    print(f"\nDefault DAG result: {default_result.final_state.value if default_result.final_state else 'Unknown'}")
    print(f"Custom DAG result: {custom_result.final_state.value if custom_result.final_state else 'Unknown'}")
    print("\n(Custom has EstrangementNullifier disabled)")
    
    return default_result, custom_result


def example_correlative_enforcement():
    """
    Example: Correlative pairing (O↔C, L↔N).
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 7: Correlative enforcement")
    print("=" * 60)
    
    case = Case(
        case_id="corr_001",
        description="""
        I promised to proofread my coworker's report by Friday.
        """,
        parties={"Writer": "promisor", "Coworker": "promisee"},
        party_of_interest="Writer"
    )
    
    dag = create_default_dag()
    result = dag.evaluate(case)
    
    print(f"\nCase: {case.description.strip()}")
    print(f"\nWriter's status: {result.final_state.value if result.final_state else 'Unknown'}")
    
    if result.final_state and result.correlative_party:
        print(f"\nD₄ s-reflection enforced:")
        print(f"  Writer (promisor): {result.final_state.value}")
        print(f"  Coworker (promisee): {result.correlative_state.value}")
        
        # Verify correlative
        expected = HohfeldianState.correlative(result.final_state)
        verified = expected == result.correlative_state
        print(f"\n  Correlative verified: {verified}")
    
    return result


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("SQND EM-DAG SYSTEM EXAMPLES")
    print("Extracted from Dear Abby corpus (n=20,034)")
    print("=" * 60)
    
    example_promise_with_release()
    example_family_with_estrangement()
    example_abuse_nullifier()
    example_money_debt()
    example_friendship_default_liberty()
    example_custom_config()
    example_correlative_enforcement()
    
    print("\n" + "=" * 60)
    print("END OF EXAMPLES")
    print("=" * 60)
