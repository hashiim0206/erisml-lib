"""
SQND Ethical Module System - DAG Configuration & Aggregation
=============================================================

The EM-DAG is traversed to produce aggregate judgments.
Key rule: FORBID is absorbing - it cannot be overridden.
"""

from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field
import re

from .core import (
    EthicalModule, Case, EthicalJudgment,
    Verdict, HohfeldianState
)
from .structural import (
    AbuseNullifierEM, DangerNullifierEM, ImpossibilityNullifierEM,
    IllegalDemandNullifierEM, EstrangementNullifierEM, CorrelativeLockEM
)
from .domains import (
    PromiseEM, FamilyEM, FriendshipEM, MoneyEM,
    RomanticEM, WeddingEM, WorkplaceEM
)


@dataclass
class DAGConfig:
    """Configuration for the EM-DAG"""
    name: str = "DearAbby_EM_DAG"
    version: str = "1.0"
    source: str = "Dear Abby corpus 1985-2017 (n=20,034)"
    
    # Aggregation settings
    forbid_is_absorbing: bool = True
    require_correlative_consistency: bool = True
    min_confidence_threshold: float = 0.5
    
    # Module enable/disable
    disabled_modules: List[str] = field(default_factory=list)


@dataclass 
class AggregatedJudgment:
    """Final aggregated judgment from the DAG"""
    case_id: str
    party: str
    final_state: Optional[HohfeldianState]
    final_verdict: Verdict
    confidence: float
    contributing_judgments: List[EthicalJudgment]
    nullifier_triggered: Optional[str] = None
    correlative_party: Optional[str] = None
    correlative_state: Optional[HohfeldianState] = None
    
    def to_dict(self) -> dict:
        return {
            "case_id": self.case_id,
            "party": self.party,
            "final_state": self.final_state.value if self.final_state else None,
            "final_verdict": self.final_verdict.value,
            "confidence": self.confidence,
            "nullifier_triggered": self.nullifier_triggered,
            "correlative": {
                "party": self.correlative_party,
                "state": self.correlative_state.value if self.correlative_state else None
            } if self.correlative_party else None,
            "judgments": [
                {"em": j.em_name, "verdict": j.verdict.value, "confidence": j.confidence}
                for j in self.contributing_judgments
            ]
        }


class DomainDetector:
    """Detects which domains apply to a case"""
    
    DOMAIN_PATTERNS = {
        "FAMILY": [
            r'\b(mother|mom|father|dad|parent|parents)\b',
            r'\b(sister|brother|sibling)\b',
            r'\b(grandmother|grandfather|grandma|grandpa)\b',
            r'\b(aunt|uncle|cousin|niece|nephew)\b',
            r'\b(son|daughter|child|children)\b',
            r'\b(husband|wife|spouse)\b',
            r'\b(in-law|mother-in-law|father-in-law)\b',
            r'\b(family|relatives)\b',
        ],
        "PROMISE": [
            r'\b(promise|promised|commitment|committed)\b',
            r'\b(agreed|agreement|word|vow)\b',
        ],
        "FRIENDSHIP": [
            r'\b(friend|friends|friendship|buddy|pal)\b',
            r'\b(best friend|close friend)\b',
        ],
        "MONEY": [
            r'\b(money|cash|loan|debt|owe|owed)\b',
            r'\b(pay|paid|payment|borrow|lend|lent)\b',
            r'\b(rent|bill|dollar|\$)\b',
        ],
        "ROMANTIC": [
            r'\b(boyfriend|girlfriend|dating|relationship)\b',
            r'\b(ex-boyfriend|ex-girlfriend|ex-husband|ex-wife)\b',
            r'\b(affair|cheating|divorce)\b',
        ],
        "WEDDING": [
            r'\b(wedding|bride|groom|bridesmaid)\b',
            r'\b(engagement|engaged|marry|married)\b',
        ],
        "WORKPLACE": [
            r'\b(boss|manager|supervisor|coworker|colleague)\b',
            r'\b(job|work|office|employer|employee)\b',
        ],
    }
    
    @classmethod
    def detect(cls, case: Case) -> List[str]:
        """Detect all applicable domains for a case"""
        text = (case.raw_text or case.description).lower()
        domains = []
        
        for domain, patterns in cls.DOMAIN_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, text):
                    domains.append(domain)
                    break
        
        return domains if domains else ["GENERAL"]


class EMDAGAggregator:
    """
    Traverses the EM-DAG and aggregates judgments.
    
    Traversal order:
    1. Nullifiers (structural) - checked first, can abort early
    2. Domain modules - filtered by applicability
    3. Aggregation - combine judgments with FORBID-absorbing semantics
    4. Correlative enforcement - ensure O↔C, L↔N pairing
    """
    
    def __init__(self, config: DAGConfig = None):
        self.config = config or DAGConfig()
        
        # Build module hierarchy
        self.nullifiers: List[EthicalModule] = [
            AbuseNullifierEM(),
            DangerNullifierEM(),
            ImpossibilityNullifierEM(),
            IllegalDemandNullifierEM(),
            EstrangementNullifierEM(),
        ]
        
        self.domain_modules: List[EthicalModule] = [
            PromiseEM(),
            FamilyEM(),
            FriendshipEM(),
            MoneyEM(),
            RomanticEM(),
            WeddingEM(),
            WorkplaceEM(),
        ]
        
        self.correlative_lock = CorrelativeLockEM()
        
        # Apply config
        for module in self.nullifiers + self.domain_modules:
            if module.name in self.config.disabled_modules:
                module.enabled = False
    
    def _run_nullifiers(self, case: Case) -> Tuple[Optional[EthicalJudgment], Optional[str]]:
        """Run nullifier modules. Returns (judgment, nullifier_name) if triggered."""
        for nullifier in self.nullifiers:
            if not nullifier.enabled:
                continue
            
            judgment = nullifier.evaluate(case)
            if not judgment.is_abstain():
                return judgment, judgment.metadata.get("nullifier")
        
        return None, None
    
    def _run_domain_modules(self, case: Case) -> List[EthicalJudgment]:
        """Run applicable domain modules"""
        judgments = []
        
        for module in self.domain_modules:
            if not module.enabled:
                continue
            
            if module.applies_to(case):
                judgment = module.evaluate(case)
                if not judgment.is_abstain():
                    judgments.append(judgment)
        
        return judgments
    
    def _aggregate_judgments(self, judgments: List[EthicalJudgment]) -> Tuple[Verdict, HohfeldianState, float]:
        """
        Aggregate multiple judgments.
        
        Rules:
        - FORBID is absorbing (if any FORBID, result is FORBID)
        - OBLIGATE beats RELEASE if confidence is higher
        - Confidence is weighted average
        """
        if not judgments:
            return Verdict.ABSTAIN, None, 0.0
        
        # Check for FORBID
        if self.config.forbid_is_absorbing:
            for j in judgments:
                if j.verdict == Verdict.FORBID:
                    return Verdict.FORBID, j.hohfeldian_state, j.confidence
        
        # Separate by verdict type
        obligate = [j for j in judgments if j.verdict == Verdict.OBLIGATE]
        release = [j for j in judgments if j.verdict == Verdict.RELEASE]
        conditional = [j for j in judgments if j.verdict == Verdict.CONDITIONAL]
        
        # Weighted decision
        o_score = sum(j.confidence for j in obligate) if obligate else 0
        l_score = sum(j.confidence for j in release) if release else 0
        
        if o_score > l_score:
            avg_conf = o_score / len(obligate)
            return Verdict.OBLIGATE, HohfeldianState.O, avg_conf
        elif l_score > o_score:
            avg_conf = l_score / len(release)
            return Verdict.RELEASE, HohfeldianState.L, avg_conf
        else:
            # Tie or only conditional
            total_conf = sum(j.confidence for j in judgments)
            avg_conf = total_conf / len(judgments) if judgments else 0.5
            return Verdict.CONDITIONAL, None, avg_conf
    
    def evaluate(self, case: Case) -> AggregatedJudgment:
        """
        Evaluate a case through the full DAG.
        
        Returns an AggregatedJudgment with final state and all contributing judgments.
        """
        contributing = []
        
        # Auto-detect domains if not specified
        if not case.domain_hints:
            case.domain_hints = DomainDetector.detect(case)
        
        # 1. Run nullifiers
        null_judgment, nullifier_name = self._run_nullifiers(case)
        if null_judgment:
            contributing.append(null_judgment)
            
            # Determine correlative
            correlative_party = None
            correlative_state = None
            if self.config.require_correlative_consistency and null_judgment.hohfeldian_state:
                parties = list(case.parties.keys())
                other_party = [p for p in parties if p != case.party_of_interest]
                if other_party:
                    correlative_party = other_party[0]
                    correlative_state = HohfeldianState.correlative(null_judgment.hohfeldian_state)
            
            return AggregatedJudgment(
                case_id=case.case_id,
                party=case.party_of_interest,
                final_state=null_judgment.hohfeldian_state,
                final_verdict=null_judgment.verdict,
                confidence=null_judgment.confidence,
                contributing_judgments=contributing,
                nullifier_triggered=nullifier_name,
                correlative_party=correlative_party,
                correlative_state=correlative_state
            )
        
        # 2. Run domain modules
        domain_judgments = self._run_domain_modules(case)
        contributing.extend(domain_judgments)
        
        # 3. Aggregate
        final_verdict, final_state, confidence = self._aggregate_judgments(domain_judgments)
        
        # 4. Correlative enforcement
        correlative_party = None
        correlative_state = None
        if self.config.require_correlative_consistency and final_state:
            parties = list(case.parties.keys())
            other_party = [p for p in parties if p != case.party_of_interest]
            if other_party:
                correlative_party = other_party[0]
                correlative_state = HohfeldianState.correlative(final_state)
        
        return AggregatedJudgment(
            case_id=case.case_id,
            party=case.party_of_interest,
            final_state=final_state,
            final_verdict=final_verdict,
            confidence=confidence,
            contributing_judgments=contributing,
            correlative_party=correlative_party,
            correlative_state=correlative_state
        )


def create_default_dag() -> EMDAGAggregator:
    """Create the default Dear Abby-derived EM-DAG"""
    return EMDAGAggregator(DAGConfig(
        name="DearAbby_EM_DAG",
        version="1.0",
        source="Dear Abby corpus 1985-2017 (n=20,034)"
    ))
