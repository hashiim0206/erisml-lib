# SQND Ethical Module System Documentation

## Overview

The EM System is an empirically-derived DAG of Ethical Modules extracted from the Dear Abby advice column corpus (n=20,034 letters, 1985-2017). It implements the NA-SQND v4.1 D₄ × U(1)_H framework for moral reasoning measurement.

## Installation

```bash
# Copy the em_system directory to your project
cp -r em_system /your/project/

# Or add to PYTHONPATH
export PYTHONPATH="${PYTHONPATH}:/path/to/em_system"
```

## Quick Start

```python
from em_system import Case, create_default_dag

# Create a case
case = Case(
    case_id="001",
    description="Morgan promised to help Alex move, but said 'only if convenient'",
    parties={"Morgan": "promisor", "Alex": "promisee"},
    party_of_interest="Morgan"
)

# Evaluate
dag = create_default_dag()
result = dag.evaluate(case)

print(result.final_state)       # HohfeldianState.L (Liberty)
print(result.correlative_state) # HohfeldianState.N (No-claim for Alex)
```

---

## Core Concepts

### Hohfeldian States

The system classifies parties into four fundamental jural positions:

| State | Name | Meaning | Example |
|-------|------|---------|---------|
| **O** | Obligation | Must do | "Morgan must help" |
| **C** | Claim | Entitled to | "Alex can demand help" |
| **L** | Liberty | Free to choose | "Morgan may help or not" |
| **N** | No-claim | Cannot demand | "Alex cannot demand help" |

### Correlatives (D₄ s-reflection)

States come in mandatory pairs:
- **O ↔ C**: If A has an obligation to B, then B has a claim against A
- **L ↔ N**: If A has liberty regarding B, then B has no-claim against A

This is structural and cannot be violated.

### Semantic Gates (D₄ Elements)

Specific phrases trigger discrete state transitions:

**O → L Gates (Release):**
- "only if convenient" → DISCRETE FLIP to L
- "no pressure" → DISCRETE FLIP to L
- "feel free" → DISCRETE FLIP to L

**L → O Gates (Binding):**
- "I promise" → Creates O
- "I agree" → Creates O
- "gave my word" → Strong O

---

## Architecture

### Module Hierarchy

```
ROOT: Structural Layer
├── CorrelativeLock (enforces O↔C, L↔N)
└── Nullifiers (override everything)
    ├── AbuseNullifier (n=582 in corpus)
    ├── DangerNullifier (n=218)
    ├── ImpossibilityNullifier (n=144)
    ├── IllegalDemandNullifier (n=57)
    └── EstrangementNullifier (n=32, family only)

DOMAIN: Domain Modules
├── PromiseEM (O-rate: 32.2% - HIGHEST)
├── FamilyEM (71% of corpus)
├── FriendshipEM (L-rate: 11.4% - HIGHEST)
├── MoneyEM (time-invariant obligations)
├── RomanticEM
├── WeddingEM
└── WorkplaceEM
```

### Traversal Order

1. **Domain Detection**: Auto-detect applicable domains from case text
2. **Nullifier Check**: Run structural nullifiers (can abort early)
3. **Domain Evaluation**: Run applicable domain modules
4. **Aggregation**: Combine judgments (FORBID is absorbing)
5. **Correlative Enforcement**: Ensure O↔C, L↔N pairing

---

## API Reference

### Case

```python
@dataclass
class Case:
    case_id: str                    # Unique identifier
    description: str                # Case description
    parties: Dict[str, str]         # party_name -> role
    party_of_interest: str          # Which party to classify
    facts: List[EthicalFact]        # Explicit facts
    raw_text: Optional[str]         # Full text for pattern matching
    domain_hints: List[str]         # Pre-specified domains (auto-detected if empty)
```

### EthicalJudgment

```python
@dataclass
class EthicalJudgment:
    em_name: str                           # Module that produced this
    verdict: Verdict                       # FORBID, ALLOW, OBLIGATE, RELEASE, etc.
    hohfeldian_state: Optional[HohfeldianState]  # O, C, L, or N
    confidence: float                      # 0.0 - 1.0
    reasons: List[str]                     # Explanation
    metadata: Dict[str, Any]               # Additional data
```

### AggregatedJudgment

```python
@dataclass
class AggregatedJudgment:
    case_id: str
    party: str
    final_state: Optional[HohfeldianState]
    final_verdict: Verdict
    confidence: float
    contributing_judgments: List[EthicalJudgment]
    nullifier_triggered: Optional[str]
    correlative_party: Optional[str]
    correlative_state: Optional[HohfeldianState]
```

### DAGConfig

```python
@dataclass
class DAGConfig:
    name: str = "DearAbby_EM_DAG"
    version: str = "1.0"
    source: str = "Dear Abby corpus 1985-2017"
    forbid_is_absorbing: bool = True      # FORBID overrides all
    require_correlative_consistency: bool = True
    min_confidence_threshold: float = 0.5
    disabled_modules: List[str] = []      # Module names to disable
```

---

## Domain Modules Reference

### PromiseEM

**Empirical basis:** 1,449 letters, 32.2% O-rate (highest)

**Key insight:** Promises are the PRIMARY obligation generator.

| Pattern | Effect | Confidence |
|---------|--------|------------|
| "only if convenient" | O → L (discrete gate) | 0.95 |
| "no pressure" | O → L (discrete gate) | 0.90 |
| "I promise" | L → O | 0.95 |
| "agreed" | L → O | 0.90 |

### FamilyEM

**Empirical basis:** 14,304 letters (71%), 18.5% O-rate

**Key insight:** Family creates PRESSURE, not automatic obligation.

| Relationship | Default | Notes |
|--------------|---------|-------|
| Parent → minor child | O (strong) | Duty of care |
| Adult child → elderly parent | O (moderate) | Contested |
| Sibling → sibling | L | No inherent duty |
| In-law | L | No blood duty |

### FriendshipEM

**Empirical basis:** 4,990 letters, 11.4% L-rate (highest)

**Key insight:** Friendship defaults to LIBERTY.

| Pattern | Effect |
|---------|--------|
| Request without acceptance | L (default) |
| Explicit acceptance | O |
| "Best friend" framing | Slight O strengthening |

### MoneyEM

**Empirical basis:** 7,330 letters, 17.4% O-rate

**Key insight:** Money obligations are TIME-INVARIANT.

| Pattern | Effect |
|---------|--------|
| Loan/borrow | O (persists) |
| Gift | L (no repayment) |
| "Pay you back" | O |
| Forgiveness | O nullified |

---

## Nullifiers

Nullifiers override ALL domain-specific obligations.

| Nullifier | Corpus Count | Effect |
|-----------|--------------|--------|
| **Abuse** | 582 | O nullified |
| **Danger** | 218 | O nullified |
| **Impossibility** | 144 | O nullified (ought implies can) |
| **Illegal** | 57 | C nullified (no claim to illegal acts) |
| **Estrangement** | 32 | Family O nullified |

---

## Customization

### Disabling Modules

```python
from em_system import DAGConfig, EMDAGAggregator

config = DAGConfig(
    disabled_modules=["EstrangementNullifier", "WeddingEM"]
)
dag = EMDAGAggregator(config)
```

### Adding Custom Modules

```python
from em_system import EthicalModule, Case, EthicalJudgment, Verdict, HohfeldianState

class CustomEM(EthicalModule):
    def __init__(self):
        super().__init__(
            name="CustomDomain",
            description="My custom domain module",
            priority=100
        )
    
    def applies_to(self, case: Case) -> bool:
        return "CUSTOM" in case.domain_hints
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        # Your logic here
        return self._judgment(
            Verdict.OBLIGATE,
            HohfeldianState.O,
            confidence=0.8,
            reasons=["Custom rule applied"]
        )

# Add to DAG
dag = EMDAGAggregator()
dag.domain_modules.append(CustomEM())
```

### Adding Facts to Cases

```python
case = Case(
    case_id="001",
    description="...",
    parties={"A": "role", "B": "role"},
    party_of_interest="A"
)

# Add explicit facts
case.add_fact("promise_made", True, source="human")
case.add_fact("abuse_present", True, source="classifier", confidence=0.9)
```

---

## Integration with Dear Ethicist Game

The EM system can be used as the backend for the "Dear Ethicist" game:

```python
from em_system import Case, create_default_dag

def evaluate_letter(letter_text: str, writer_name: str, other_party: str) -> dict:
    """Evaluate a Dear Ethicist letter"""
    case = Case(
        case_id=generate_id(),
        description=letter_text,
        raw_text=letter_text,
        parties={writer_name: "writer", other_party: "other"},
        party_of_interest=writer_name
    )
    
    dag = create_default_dag()
    result = dag.evaluate(case)
    
    return {
        "writer_status": result.final_state.value if result.final_state else None,
        "other_status": result.correlative_state.value if result.correlative_state else None,
        "confidence": result.confidence,
        "verdict": result.final_verdict.value,
        "reasoning": [j.reasons for j in result.contributing_judgments]
    }
```

---

## Empirical Validation

The EM system is derived from 70 years of cross-cultural advice column data:

| Metric | Value |
|--------|-------|
| Letters analyzed | 20,034 |
| Year range | 1985-2017 |
| Format validated since | 1956 |
| Cultural reach | Global syndication |

### Key Empirical Findings

1. **Discrete gates confirmed**: "Only if convenient" produces binary O→L flip (supports D₄ over SU(2))

2. **Correlative consistency**: Natural language respects O↔C, L↔N pairing

3. **Nullifier priority**: Abuse/danger override ALL domain obligations

4. **Time invariance**: Money obligations persist; social obligations decay

---

## File Structure

```
em_system/
├── __init__.py      # Package exports
├── core.py          # Base types (Case, Judgment, etc.)
├── structural.py    # Nullifiers and correlative lock
├── domains.py       # Domain-specific modules
├── dag.py           # DAG configuration and aggregator
├── examples.py      # Usage examples
└── README.md        # This documentation
```

---

## License

This system is derived from publicly available Dear Abby content for research purposes. The code is provided for academic and research use under the NA-SQND framework.

## Citation

```
Bond, A.H. (2026). Non-Abelian Gauge Structure in Stratified Quantum 
Normative Dynamics. NA-SQND v4.1.

EM-DAG extracted from Dear Abby corpus by Claude (Anthropic).
```
