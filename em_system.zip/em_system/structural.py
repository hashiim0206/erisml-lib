"""
SQND Ethical Module System - Structural Modules
================================================

Root-level modules that enforce structural constraints.
These have priority over all domain-specific modules.

Nullifiers are ABSORBING - once triggered, they override everything.
"""

import re
from typing import List
from .core import (
    EthicalModule, Case, EthicalJudgment, 
    Verdict, HohfeldianState, EthicalFact
)


class NullifierEM(EthicalModule):
    """
    Base class for nullifier modules.
    
    Nullifiers override all domain-specific obligations.
    Empirical basis: Dear Abby corpus shows these patterns
    universally void obligations regardless of context.
    """
    
    def __init__(self, name: str, description: str, 
                 triggers: List[str], corpus_count: int):
        super().__init__(name, description, priority=1000)  # Highest priority
        self.triggers = triggers
        self.empirical_basis = {
            "corpus_count": corpus_count,
            "source": "Dear Abby 1985-2017"
        }
    
    def _check_triggers(self, case: Case) -> bool:
        """Check if any trigger pattern matches"""
        text = (case.raw_text or case.description).lower()
        for trigger in self.triggers:
            if re.search(trigger, text):
                return True
        return False


class AbuseNullifierEM(NullifierEM):
    """
    Abuse nullifies all obligations.
    
    Empirical basis: 582 letters in corpus where abuse
    is cited as nullifying family/social obligations.
    """
    
    def __init__(self):
        super().__init__(
            name="AbuseNullifier",
            description="Abuse voids all obligations to the abuser",
            triggers=[
                r'\b(abuse|abused|abusive|abuser)\b',
                r'\b(hit|beat|hitting|beating)\b.*\b(me|him|her|them)\b',
                r'\b(violent|violence)\b',
                r'\b(molest|assault)\b',
            ],
            corpus_count=582
        )
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        # Check explicit fact first
        if case.fact_value("abuse_present", False):
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=0.95,
                reasons=["Abuse nullifies obligation to abuser"],
                nullifier="abuse"
            )
        
        # Check text patterns
        if self._check_triggers(case):
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=0.85,
                reasons=["Abuse pattern detected - obligation nullified"],
                nullifier="abuse"
            )
        
        return self._abstain("No abuse detected")


class DangerNullifierEM(NullifierEM):
    """
    Danger to self nullifies obligations.
    
    Empirical basis: 218 letters citing danger as reason
    to void social/family obligations.
    """
    
    def __init__(self):
        super().__init__(
            name="DangerNullifier", 
            description="Danger to self voids obligations",
            triggers=[
                r'\b(dangerous|unsafe|danger)\b',
                r'\b(fear for|afraid for)\b.*(life|safety)\b',
                r'\b(threaten|threatened|threatening)\b',
                r'\b(harm|hurt)\b.*\b(me|myself)\b',
            ],
            corpus_count=218
        )
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if case.fact_value("danger_present", False):
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=0.95,
                reasons=["Danger nullifies obligation"],
                nullifier="danger"
            )
        
        if self._check_triggers(case):
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=0.80,
                reasons=["Danger pattern detected - obligation nullified"],
                nullifier="danger"
            )
        
        return self._abstain("No danger detected")


class ImpossibilityNullifierEM(NullifierEM):
    """
    Impossibility nullifies obligations (ought implies can).
    
    Empirical basis: 144 letters citing impossibility.
    """
    
    def __init__(self):
        super().__init__(
            name="ImpossibilityNullifier",
            description="Cannot be obligated to do the impossible",
            triggers=[
                r'\b(impossible|can\'t possibly|cannot possibly)\b',
                r'\b(no way to|no way I can)\b',
                r'\b(physically impossible|literally impossible)\b',
                r'\b(beyond my control)\b',
            ],
            corpus_count=144
        )
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if case.fact_value("impossible", False):
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=0.95,
                reasons=["Ought implies can - impossibility voids obligation"],
                nullifier="impossibility"
            )
        
        if self._check_triggers(case):
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=0.75,
                reasons=["Impossibility pattern detected"],
                nullifier="impossibility"
            )
        
        return self._abstain("No impossibility detected")


class IllegalDemandNullifierEM(NullifierEM):
    """
    No valid claim to illegal acts.
    
    Empirical basis: 57 letters.
    """
    
    def __init__(self):
        super().__init__(
            name="IllegalDemandNullifier",
            description="No one has a claim to illegal acts",
            triggers=[
                r'\b(illegal|against the law|unlawful)\b',
                r'\b(crime|criminal)\b',
                r'\b(break the law)\b',
            ],
            corpus_count=57
        )
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if case.fact_value("request_illegal", False):
            return self._judgment(
                Verdict.FORBID,  # FORBID the claim, not release
                HohfeldianState.N,  # Demander has no-claim
                confidence=0.99,
                reasons=["No valid claim to illegal acts"],
                nullifier="illegal"
            )
        
        if self._check_triggers(case):
            return self._judgment(
                Verdict.FORBID,
                HohfeldianState.N,
                confidence=0.85,
                reasons=["Illegal demand detected - claim nullified"],
                nullifier="illegal"
            )
        
        return self._abstain("No illegal demand detected")


class EstrangementNullifierEM(NullifierEM):
    """
    Estrangement weakens/nullifies family obligations.
    
    Empirical basis: 32 letters explicitly, but pattern
    appears throughout family domain.
    """
    
    def __init__(self):
        super().__init__(
            name="EstrangementNullifier",
            description="Estrangement weakens family obligations",
            triggers=[
                r'\b(estranged|estrangement)\b',
                r'\b(no contact|cut off|cut contact)\b',
                r'\b(haven\'t spoken|don\'t speak)\b.*\b(years|months)\b',
                r'\b(disowned)\b',
            ],
            corpus_count=32
        )
    
    def applies_to(self, case: Case) -> bool:
        # Only applies to family domain
        return "FAMILY" in case.domain_hints
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        if not self.applies_to(case):
            return self._abstain("Not a family case")
        
        if case.fact_value("estranged", False):
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=0.85,
                reasons=["Estrangement nullifies family obligation"],
                nullifier="estrangement"
            )
        
        if self._check_triggers(case):
            return self._judgment(
                Verdict.RELEASE,
                HohfeldianState.L,
                confidence=0.75,
                reasons=["Estrangement pattern detected"],
                nullifier="estrangement"
            )
        
        return self._abstain("No estrangement detected")


class CorrelativeLockEM(EthicalModule):
    """
    Enforces D4 s-reflection: O↔C, L↔N
    
    This is a STRUCTURAL constraint, not learned.
    Any judgment on party A implies the correlative on party B.
    """
    
    def __init__(self):
        super().__init__(
            name="CorrelativeLock",
            description="Enforces Hohfeldian correlative pairs",
            priority=999  # Just below nullifiers
        )
    
    def evaluate(self, case: Case) -> EthicalJudgment:
        # This EM validates rather than produces judgments
        # It's used by the aggregator to ensure consistency
        return self._abstain("Structural constraint - used by aggregator")
    
    @staticmethod
    def enforce(state: HohfeldianState, party_a: str, party_b: str) -> dict:
        """
        Given a state for party_a, return the implied state for party_b.
        
        Returns dict mapping party names to their states.
        """
        correlative = HohfeldianState.correlative(state)
        return {
            party_a: state,
            party_b: correlative
        }
