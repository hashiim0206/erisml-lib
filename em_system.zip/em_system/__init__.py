"""
SQND Ethical Module System
==========================

An empirically-derived DAG of Ethical Modules extracted from
the Dear Abby corpus (n=20,034 letters, 1985-2017).

Framework: NA-SQND v4.1 D₄ × U(1)_H

Quick Start:
-----------
    from em_system import Case, create_default_dag
    
    # Create a case
    case = Case(
        case_id="001",
        description="Morgan promised to help Alex move, but said 'only if convenient'",
        parties={"Morgan": "promisor", "Alex": "promisee"},
        party_of_interest="Morgan"
    )
    
    # Evaluate through the DAG
    dag = create_default_dag()
    result = dag.evaluate(case)
    
    print(f"Morgan's status: {result.final_state}")  # L (Liberty)
    print(f"Alex's status: {result.correlative_state}")  # N (No-claim)

Module Hierarchy:
----------------
1. Structural Layer (Root)
   - CorrelativeLock: O↔C, L↔N enforcement
   - Nullifiers: Abuse, Danger, Impossibility, Illegal, Estrangement

2. Domain Layer
   - Promise (highest O-rate: 32.2%)
   - Family (71% of corpus)
   - Friendship (highest L-rate: 11.4%)
   - Money (time-invariant obligations)
   - Romantic
   - Wedding
   - Workplace

Key Findings:
------------
- PROMISE is the primary obligation generator
- FRIENDSHIP defaults to LIBERTY
- FAMILY creates pressure, not automatic obligation
- Abuse nullifies ALL obligations (n=582 in corpus)
- "Only if convenient" is a DISCRETE gate (supports D₄ model)
"""

from .core import (
    HohfeldianState,
    Verdict,
    EthicalFact,
    EthicalJudgment,
    Case,
    EthicalModule,
)

from .structural import (
    NullifierEM,
    AbuseNullifierEM,
    DangerNullifierEM,
    ImpossibilityNullifierEM,
    IllegalDemandNullifierEM,
    EstrangementNullifierEM,
    CorrelativeLockEM,
)

from .domains import (
    DomainEM,
    PromiseEM,
    FamilyEM,
    FriendshipEM,
    MoneyEM,
    RomanticEM,
    WeddingEM,
    WorkplaceEM,
)

from .dag import (
    DAGConfig,
    AggregatedJudgment,
    DomainDetector,
    EMDAGAggregator,
    create_default_dag,
)

__version__ = "1.0.0"
__author__ = "A. Bond / Claude"
__source__ = "Dear Abby corpus 1985-2017"

__all__ = [
    # Core types
    "HohfeldianState",
    "Verdict", 
    "EthicalFact",
    "EthicalJudgment",
    "Case",
    "EthicalModule",
    
    # Structural modules
    "NullifierEM",
    "AbuseNullifierEM",
    "DangerNullifierEM",
    "ImpossibilityNullifierEM",
    "IllegalDemandNullifierEM",
    "EstrangementNullifierEM",
    "CorrelativeLockEM",
    
    # Domain modules
    "DomainEM",
    "PromiseEM",
    "FamilyEM",
    "FriendshipEM",
    "MoneyEM",
    "RomanticEM",
    "WeddingEM",
    "WorkplaceEM",
    
    # DAG
    "DAGConfig",
    "AggregatedJudgment",
    "DomainDetector",
    "EMDAGAggregator",
    "create_default_dag",
]
