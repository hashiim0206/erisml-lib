"""
SQND Ethical Module System - Core Types
========================================

Base classes and types for the EM-DAG system.
Extracted from Dear Abby corpus (n=20,034 letters, 1985-2017)
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any
from abc import ABC, abstractmethod


class HohfeldianState(Enum):
    """The four Hohfeldian jural positions"""
    O = "OBLIGATION"    # Duty to act
    C = "CLAIM"         # Right to demand
    L = "LIBERTY"       # Freedom to act or not
    N = "NO_CLAIM"      # No right to demand
    
    @classmethod
    def correlative(cls, state: 'HohfeldianState') -> 'HohfeldianState':
        """Return the correlative (D4 s-reflection)"""
        mapping = {cls.O: cls.C, cls.C: cls.O, cls.L: cls.N, cls.N: cls.L}
        return mapping[state]
    
    @classmethod
    def negation(cls, state: 'HohfeldianState') -> 'HohfeldianState':
        """Return the negation (D4 r²-rotation)"""
        mapping = {cls.O: cls.L, cls.L: cls.O, cls.C: cls.N, cls.N: cls.C}
        return mapping[state]


class Verdict(Enum):
    """EM output verdicts with defined semantics"""
    FORBID = "FORBID"           # Hard no - ABSORBING (cannot be overridden)
    ALLOW = "ALLOW"             # Permitted
    OBLIGATE = "OBLIGATE"       # Required (maps to O)
    RELEASE = "RELEASE"         # Released from obligation (maps to L)
    ESCALATE = "ESCALATE"       # Needs human review
    CONDITIONAL = "CONDITIONAL" # Context-dependent
    ABSTAIN = "ABSTAIN"         # This EM doesn't apply


@dataclass
class EthicalFact:
    """A single fact relevant to ethical evaluation"""
    name: str
    value: Any
    source: str  # "rule", "classifier", "human", "corpus"
    confidence: float = 1.0
    provenance: Optional[str] = None
    
    def __bool__(self):
        return bool(self.value)


@dataclass
class EthicalJudgment:
    """Output of an EM evaluation"""
    em_name: str
    verdict: Verdict
    hohfeldian_state: Optional[HohfeldianState] = None
    confidence: float = 1.0
    reasons: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def is_forbid(self) -> bool:
        return self.verdict == Verdict.FORBID
    
    def is_abstain(self) -> bool:
        return self.verdict == Verdict.ABSTAIN


@dataclass 
class Case:
    """A case to be evaluated by the EM-DAG"""
    case_id: str
    description: str
    parties: Dict[str, str]  # party_name -> role
    party_of_interest: str   # which party are we classifying
    facts: List[EthicalFact] = field(default_factory=list)
    raw_text: Optional[str] = None
    domain_hints: List[str] = field(default_factory=list)
    
    def get_fact(self, name: str) -> Optional[EthicalFact]:
        """Get a fact by name"""
        for f in self.facts:
            if f.name == name:
                return f
        return None
    
    def has_fact(self, name: str) -> bool:
        """Check if a fact exists"""
        return self.get_fact(name) is not None
    
    def fact_value(self, name: str, default: Any = None) -> Any:
        """Get fact value or default"""
        f = self.get_fact(name)
        return f.value if f else default
    
    def add_fact(self, name: str, value: Any, source: str = "rule", 
                 confidence: float = 1.0) -> 'Case':
        """Add a fact to the case"""
        self.facts.append(EthicalFact(name, value, source, confidence))
        return self


class EthicalModule(ABC):
    """
    Base class for all Ethical Modules.
    
    An EM consumes facts about a case and emits a judgment.
    EMs must be:
    - Deterministic (same input → same output)
    - Side-effect free
    - Monotonic in severity (can only tighten constraints)
    """
    
    def __init__(self, name: str, description: str, priority: int = 0):
        self.name = name
        self.description = description
        self.priority = priority  # Higher = evaluated first
        self.enabled = True
        self.children: List['EthicalModule'] = []
        self.empirical_basis: Dict[str, Any] = {}
    
    @abstractmethod
    def evaluate(self, case: Case) -> EthicalJudgment:
        """Evaluate a case and return judgment"""
        pass
    
    def applies_to(self, case: Case) -> bool:
        """Check if this EM is relevant to the case"""
        return True
    
    def add_child(self, child: 'EthicalModule') -> 'EthicalModule':
        """Add a child EM"""
        self.children.append(child)
        return self
    
    def _judgment(self, verdict: Verdict, state: HohfeldianState = None,
                  confidence: float = 1.0, reasons: List[str] = None,
                  **metadata) -> EthicalJudgment:
        """Helper to construct judgments"""
        return EthicalJudgment(
            em_name=self.name,
            verdict=verdict,
            hohfeldian_state=state,
            confidence=confidence,
            reasons=reasons or [],
            metadata=metadata
        )
    
    def _abstain(self, reason: str = "Not applicable") -> EthicalJudgment:
        """Helper for abstention"""
        return self._judgment(Verdict.ABSTAIN, reasons=[reason])
    
    def _forbid(self, reason: str, **metadata) -> EthicalJudgment:
        """Helper for FORBID (absorbing)"""
        return self._judgment(Verdict.FORBID, reasons=[reason], **metadata)
